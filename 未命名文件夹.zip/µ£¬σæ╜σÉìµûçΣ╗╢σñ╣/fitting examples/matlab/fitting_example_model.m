%
% Evaulate some model function (e.g. peak shape function) with the given parameters,
% to be used by some nonlinear optimizer, e.g. lsqcurvefit.
% 
% This function also supports fitting several peaks at the same time,
% by taking each peak's parameters as a separate row in the parameters-matrix
% and returning the sum of their peak shape functions.
%
% PARAMETERS
%  parameters (N-by-P) Matrix of the parameters.
%             Each row represents a separate function (e.g. one per peak),
%             each column has the different parameters for that function.
%  x          (1-by-M) or (M-by-1) Array of the independent varaible,
%             also called abscissa or for instance energy axis.
% RETURNS
%  y          (same size as x) Sum of the model functions,
%             evaulated with the given parameters at the given x-values.
% 
% SEE ALSO
%  lsqcurvefit, optimset, fminsearch
%
function y = fitting_example_model(parameters, x)

% Extract the named parameters from the coefficient matrix:
x0    = parameters(:,1);
Gamma = parameters(:,2);
area  = parameters(:,3);

% Initiate output spectrum
y = 0;

% For each term (peak) included in the model
for index = 1:size(parameters,1)
  
  % Use triangular function as (unrealistic) peak shape:
  relative_x = x - x0(index);
  y_here = area(index) * max(0, Gamma(index)-abs(relative_x)) / (Gamma(index).^2);
  
  % Add to the total spectrum:  
  y = y + y_here;
end