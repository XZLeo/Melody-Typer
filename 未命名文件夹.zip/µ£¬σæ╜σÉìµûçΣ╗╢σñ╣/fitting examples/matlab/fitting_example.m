% Demonstration of how Matlab routines for fitting a model function
% to data can be used.
% Licensed under http://creativecommons.org/licenses/by/3.0/
% Original version by erik.mansson@sljus.lu.se, 2012-03-04.
%
% If you don't use Matlab:
% In Octave, "fminunc" is possible to use instead of "fminsearch", but
% when tested in Octave 3.2.4 on Windows it hardly improved the fit compared to initual guess.
% If you use Scilab, an overview can be found in
% http://www.scilab.org/products/scilab/features/optimization/Datasheet-Optimization-in-Scilab


raw_data = load('Ar_3p.txt');
energy    = raw_data(:,1);
intensity = raw_data(:,2);

figure(1);
plot(energy, intensity, '.')

%% Make initial guess  (Click here and press Ctrl+Enter to run only this cell)
% For nonlinear fitting one needs to make a guess for the parameters. It
% doesn't have to be very good, but should make the function have some
% resemblance to the target data.
% The parameters for different peaks (terms) are separated by semicolon
% (different rows in the matrix).
% Open fitting_example_model to see what the parameters mean,
% or type "help fitting_example_model".
% Or just vary them, and press Ctrl+Enter to see how diagram is affectd!
initial_guess = [15.4  0.1  800;  15.6  0.1   800];
plot(energy, fitting_example_model(initial_guess, energy), '-r', energy, intensity, '.b');


% More about automatic optimization:
% If your guess is too bad, the optimizer may be "led to an undesired fit",
% e.g. with negative areas or fitting a very wide peak to account for a
% constant background or two physical peaks. You should look out for
% such things and try to avoid them by refining your initial guess,
% and/or try different fitters (their internal algorithms are sometimes the same
% but can be affected by options and the presence of lower&upper bounds).
% If you need it you can first subtract a background from the experimental
% intensity, and/or you can split the raw diagram into smaller parts and
% fit one part at a time if that makes it easier.
%
% An optimization problem can be described as standing in a hilly landscape
% (height representing sum of fit-errors^2). If you move horizontally
% (change the parameters) your elevation (errors) will also
% change depending on the underlying function (the optimization problem or the
% landscape). Now the aim is to find the lowest point (smallest error)
% in this landscape. If you are a ball you will probably roll downhill
% along the (negative) gradient and oscillate a bit until you stop at a
% the bottom of a valley. This is a local minimum. There may however, be
% other minima, if you would have backed initially to the other side of a
% hill, the valley on the other side may have been even deeper, or
% contained a cave... Naturally, a complicated function may have many local
% minima and it is hard to make a program that in limited time always finds
% the deepest. So you can think of it as the optimizer finding some local
% minimum, normally one "near" your initial guess.
% A very small ball could get stuck behind a small stone or some grass on
% flatland, while a big ball perhaps can cross such obstacles and be better
% at finding the local minimum representative of a larger area. The design of
% optimization algorithms has to deal with such things and can be more or
% less successful.



%% Fit using fminsearch  (Click here and press Ctrl+Enter to run only this cell)
% Here we have to explicitly express that the squared sum of residuals should be
% minimized, because fminsearch only handles functions that return a single
% scalar number.
% The "@(a) expression" means we define an anonymous function
% that takes the parameter a and returns the expression evaulated:
sum_squared_residual = @(param) sum((fitting_example_model(param, energy)-intensity).^2);

residual_norm_initial = sum_squared_residual(initial_guess)

% Setings:
options = optimset(); % Default: don't show stuff while plotting
options = optimset(options, 'PlotFcns',{@optimplotfval,@optimplotx}); % To show residual and current parameters while fitting
% Fit!
[parameters_fms,y,exitflag,output] = fminsearch(sum_squared_residual, initial_guess, options);

% Display result:
figure(1);
plot(energy, fitting_example_model(parameters_fms, energy), '-r', energy, intensity, '.b');
residual_norm_fms = sum_squared_residual(parameters_fms);
title(sprintf('With fminsearch. Sum of squared residuals = %.5G', residual_norm_fms))
% Extract the named parameters from the parameter matrix:
x0    = parameters_fms(:,1)
Gamma = parameters_fms(:,2)
area  = parameters_fms(:,3)

%% Fit using lsqcurvefit  (Click here and press Ctrl+Enter to run only this cell)
% Here we just give the model function and the data, then
% lsqcurvefit will internally compute something like sum_squared_residual.
% This means lsqcurvefit has access to more information, and that it 
% can use different algorithms than fminsearch.
% It can for instance notice that a certain parameter mainly affects at
% low energies and then realize that other parameters need to be varied
% in order to correct a remaining residual at high energies.

% To not restrict parameter values
upper = [];
lower = [];
% To only allow parameter value between lower and upper bounds
% Currently commented out to not use any constraint.
% (set these after you have an acceptable initial guess)
%upper         = [16  0.2  1500;  16  0.2  1500];
%lower         = [15  0.0   300;  15  0.0   300];

% Settings
options = optimset(); % Default, algorithm = 'trust-region-reflective'
% options = optimset(options, 'Algorithm', 'levenberg-marquardt'); lower = []; upper = []; % To use another algorithm, which can't handle lower & upper bounds
options = optimset(options, 'PlotFcns',{@optimplotresnorm,@optimplotx}); % To show residual and current parameters while fitting
% options = optimset(options, 'TolFun', 1E-16, 'TolX',1E-11); % try harder

% Fit!
[parameters_lsqc,residual_norm_lsqc,residuals,exitflag,fit_info] = lsqcurvefit( ...
                  @fitting_example_model, initial_guess, energy, intensity, lower, upper, options);

% Display results
figure(1);
plot(energy, fitting_example_model(parameters_lsqc, energy), '-g', energy, intensity, '.b');
title(sprintf('With lsqcurvefit. Sum of squared residuals = %.5G', residual_norm_lsqc))
% Extract the named parameters from the parameter matrix:
x0    = parameters_lsqc(:,1)
Gamma = parameters_lsqc(:,2)
area  = parameters_lsqc(:,3)


%% Display both results together  (Click here and press Ctrl+Enter to run only this cell)
plot(energy, fitting_example_model(parameters_fms, energy), '-r', ...
     energy, fitting_example_model(parameters_lsqc, energy), '--g', ...
     energy, intensity, '.b');
legend(sprintf('With fminsearch. Sum of squared residuals = %.5G', residual_norm_fms), ...
       sprintf('With lsqcurvefit. Sum of squared residuals = %.5G', residual_norm_lsqc), ...
       'Experimental data', 'Location','NO')



%% Fit using "fit"  (Click here and press Ctrl+Enter to run only this cell)
% The result is normally the same as by lsqcurvefit (same algorithms
% supported).
% A benefit is that "fit" also gives confidence intervals for the found parameters.
% A downside is that the number of peaks can't be varied so easily, you need one
% name per parameter (not just a parameters-matrix).
% 
% If you in some other time need to fit standard functions, like gaussian
% peaks without lorentzian convolution, it is particularly simple with "fit"
% -- run "cflibhelp" and "help fittype" for more info on built-in models.
%
% Here we use our custom model instead. Name c1 for center of first peak,
% w1 for width and a1 for area, then ...2 for second peak, and so on.
model = fittype(@(c1,c2,w1,w2,a1,a2, x) fitting_example_model([c1 w1 a1; c2 w2 a2],x));

% The initial guess and bounds need to be given as column vectors to
% "fit", which is acieved by indexing like "initial_guess(:)".
% The guess and lower & upper bounds are reused from the above cell with
% lsqcurvefit, so you may want to re-run that cell to turn/off lower&upper bounds.
[fitted,goodness,output] = fit(energy, intensity, model, ...
  'StartPoint',initial_guess(:), 'Lower',lower(:), 'Upper',upper(:));

% Display results:
fitted
confint(fitted, 0.95) % extract confidence interval estimates (95%) for each parameter

parameters_fit = reshape(coeffvalues(fitted),[2 3]); % create matrix as for the other methods
residual_norm_fit = goodness.sse; % = sum_squared_residual(parameters_fit)
figure(1);
plot(energy, feval(fitted, energy), '-m', energy, intensity, '.b');
title(sprintf('With fit. Sum of squared residuals = %.5G', residual_norm_fit))

% Open curve fitting toolbox. Not necessary.
% cftool(energy, intensity);

%% Display all fits together
figure(1);
plot(energy, fitting_example_model(parameters_fms , energy), '-r', ...
     energy, fitting_example_model(parameters_lsqc, energy), '--g', ...
     energy, fitting_example_model(parameters_fit , energy), ':m', ...
     energy, intensity, '.b');
legend(sprintf('With fminsearch. Sum of squared residuals = %.5G', residual_norm_fms), ...
       sprintf('With lsqcurvefit. Sum of squared residuals = %.5G', residual_norm_lsqc), ...
       sprintf('With fit. Sum of squared residuals = %.5G', residual_norm_fit), ...
       'Experimental data', 'Location','NO')

