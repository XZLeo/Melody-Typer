"""
Script that demonstrates fitting data using scipy's leastsq function.
"""

# Import packages
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt

# First, load the data set using numpy's 'genfromtxt' function
data = np.genfromtxt('dummy_data.txt')
# 'data' is now numpy array with 2 columns. The x data is in the first column,
# the y-data is in the second column. Next, I save the x-data and the y-data in separate
# arrays. Not strictly necessary, but it makes the script easier to follow
xdata = data[:, 0]
ydata = data[:, 1]


# Define the 'model' that we will fit the data with
# 'x' is the independent variable (x-axis), while the array
# 'p' contains all the model parameters
def mymodel(x, p):
    y = p[0] * np.exp(-4*np.log(2)*(x-p[1])**2 / p[2]**2) + p[3]
    return y


# Define a function that calculates the residual vector, that is, the difference
# between the y-data from the dummy data set and the model function
def residuals(p):
    return ydata - mymodel(xdata, p)


# Now, fit the model function to the data using the 'leastsq' function from
# the scipy.optimize package. The leastsq function searches for a set of model
# parameters that minimize the difference between model and data
# (it does so by minimizing the sum of squared residuals)
init_guess = np.array([3.0, 1, 1.0, 2.0])
popt, msg = opt.leastsq(residuals, init_guess)

# Evaluate the model using the parameters obtained from the fit
xfit = np.linspace(0, 1, 101)
yfit = mymodel(xfit, popt)

# Create a plot showing the data and the fit
fig, ax = plt.subplots(figsize=(5, 4))

ax.plot(xfit, yfit, '-', color='C0', linewidth=4, alpha=0.6, label='Fit')
ax.plot(xdata, ydata, 'o', color='C3', label='Data')

ax.legend()
ax.set_xlabel('X')
ax.set_ylabel('Y')

plt.tight_layout()
plt.show()
